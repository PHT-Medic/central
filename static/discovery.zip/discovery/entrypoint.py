#!/usr/bin/env python

import pickle
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import os
import numpy as np
import matplotlib.pyplot as plt

_RESIDUES = [
    'A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', '-'
]

_RESIDUE_ENCODING = {
    residue:  (index * [0]) + [1] + (len(_RESIDUES) - index - 1) * [0] for index, residue in enumerate(_RESIDUES)
}

_CXCR4 = 'CXCR4'
_CCR5 = 'CCR5'


def _flatten(l):
    return [item for sublist in l for item in sublist]


def _load_sequences_as_encoded(file_path: str, class_labels):
    x = []
    y = []

    feature_space_dimension = None
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            line_split = line.split()

            label = _CXCR4 if len(line_split) > 3 else line_split[2].strip()
            seq = line_split[1].strip()
            seq_encoded = _flatten(_RESIDUE_ENCODING[residue] for residue in seq)
            seq_encoded_len = len(seq_encoded)

            if feature_space_dimension is None:
                feature_space_dimension = seq_encoded_len
            elif feature_space_dimension != seq_encoded_len:
                raise ValueError('Inconsistent feature length: {} vs. {}'.format(
                    feature_space_dimension, seq_encoded_len))
            x.append(seq_encoded)
            y.append(class_labels[label])
    return x, y


def plot_results(results):
    # figure 1 sample sizes and test size
    num_stations = len(results.items()) + 1  # for all samples

    # data to plot
    train_sam = []
    test_sam = []
    acc = []

    for i in results.items():
        test_sam.append(i[1]['test_samples'])
        train_sam.append(i[1]['training_samples'])
        acc.append(i[1]['acc_total'])

    # append total column
    train_sam.append(sum(train_sam))
    test_sam.append(sum(test_sam))

    # create plot
    plt.figure(1)
    index = np.arange(num_stations)
    bar_width = 0.5
    opacity = 0.8

    p1 = plt.bar(index, train_sam, bar_width, alpha=opacity, color='deepskyblue', label='train')
    p2 = plt.bar(index, test_sam, bar_width, bottom=train_sam, alpha=opacity, color='coral', label='test')

    plt.xlabel('Stations')
    plt.ylabel('Samples')
    plt.title('Samples per Station')

    station_labels = list(range(1, len(results) + 1))
    station_labels = [str(x) for x in station_labels]
    station_labels.append('All')

    plt.xticks(index, station_labels)
    plt.legend((p1[0], p2[0]), ('train', 'test'))
    plt.legend()

    plt.tight_layout()
    plt.savefig('analysis_1.png')
    plt.show()

    # figure 2 acc over stations
    plt.figure(2)
    index = np.arange(num_stations)
    p3 = plt.plot(acc, label='Acc [%]')

    plt.xlabel('Stations')
    plt.ylabel('Accuracy [%]')
    plt.title('Accuracy over stations')

    station_labels = list(range(1, len(results) + 1))
    station_labels = [str(x) for x in station_labels]

    plt.xticks(index, station_labels)
    plt.legend('Accuracy')
    plt.legend()

    plt.tight_layout()
    plt.savefig('analysis_2.png')
    plt.show()


class Train:
    def __init__(self, model=None, data_path=None, results=None):
        # Model and results encoded with Pickle
        self.encoded_model = model
        self.data_path = data_path
        self.results = results

    def _load_model(self):
        with open(self.encoded_model, 'rb') as model_file:
            return pickle.load(file=model_file)

    def _save_model(self, model):
        with open(self.encoded_model, 'wb') as model_file:
            pickle.dump(model, model_file)

    def _load_results(self):
        try:
            with open(self.results, 'rb') as results_file:
                return pickle.load(file=results_file)
        except:
            return {'analysis': {}, 'discovery': {}}

    def _save_results(self, results):
        with open(self.results, 'wb') as results_file:
            return pickle.dump(results, results_file)

    def analysis(self):
        # Data Loading and class encoding
        x, y = _load_sequences_as_encoded(self.data_path, class_labels={
            _CCR5: 1,
            _CXCR4: 0
        })

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.10)
        classes = np.array([0, 1])

        if not os.path.isfile(self.encoded_model):
            results = self._load_results()

            model = MultinomialNB(alpha=0.01)
            model.partial_fit(x_train, y_train, classes=classes)

            acc = model.score(x_test, y_test)

            # Include hold out data in model before leaving station
            model.partial_fit(x_test, y_test, classes=classes)
            self._save_model(model)

            analysis = {'training_samples': len(x_train),
                         'test_samples': len(x_test),
                         'acc_local': acc,
                         'acc_total': acc}
            results['analysis']['analysis_exec_' + str(len(results['analysis']) + 1)] = analysis

        # Otherwise load the existing model file and add the new data to it
        else:
            results = self._load_results()

            pickle_model = self._load_model()

            acc = pickle_model.score(x_test, y_test)

            pickle_model.partial_fit(x_train, y_train, classes=classes)

            new_acc = pickle_model.score(x_test, y_test)

            # Include hold out data in model before leaving station
            pickle_model.partial_fit(x_test, y_test, classes=classes)

            self._save_model(model=pickle_model)

            analysis = {'training_samples': len(x_train),
                        'test_samples': len(x_test),
                        'acc_local': acc,
                        'acc_total': new_acc}
            results['analysis']['analysis_exec_' + str(len(results['analysis']) + 1)] = analysis

        print(results)
        plot_results(results['analysis'])
        self._save_results(results)


def main():
    train = Train(model='model.pkl', data_path='/data/sequence.txt', results='results.pkl')
    train.analysis()


if __name__ == '__main__':
    main()

