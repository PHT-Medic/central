#!/usr/bin/env python

import numpy as np
import pickle
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import os
import numpy as np
import matplotlib.pyplot as plt

_RESIDUES = [
    'A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', '-'
]

_RESIDUE_ENCODING = {
    residue:  (index * [0]) + [1] + (len(_RESIDUES) - index - 1) * [0] for index, residue in enumerate(_RESIDUES)
}

_CXCR4 = 'CXCR4'
_CCR5 = 'CCR5'


def _flatten(l):
    return [item for sublist in l for item in sublist]


def _load_sequences_as_encoded(file_path: str, class_labels):
    x = []
    y = []

    feature_space_dimension = None
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            line_split = line.split()

            label = _CXCR4 if len(line_split) > 3 else line_split[2].strip()
            seq = line_split[1].strip()
            seq_encoded = _flatten(_RESIDUE_ENCODING[residue] for residue in seq)
            seq_encoded_len = len(seq_encoded)

            if feature_space_dimension is None:
                feature_space_dimension = seq_encoded_len
            elif feature_space_dimension != seq_encoded_len:
                raise ValueError('Inconsistent feature length: {} vs. {}'.format(
                    feature_space_dimension, seq_encoded_len))
            x.append(seq_encoded)
            y.append(class_labels[label])
    return x, y


def plot_results(results):
    # figure 1 = samples over stations and total
    num_stations = len(results.items()) + 1  # for all samples

    # data to plot
    class_0 = []
    class_1 = []
    stat_samples = []

    for i in results.items():
        stat_samples.append(i[1]['total_samples'])
        class_0.append(i[1]['class_0_num'])
        class_1.append(i[1]['class_1_num'])

    # append total column
    class_0.append(sum(class_0))
    class_1.append(sum(class_1))

    # create plot
    fig, ax = plt.subplots()
    index = np.arange(num_stations)
    bar_width = 0.5
    opacity = 0.8

    p1 = plt.bar(index, class_0, bar_width, alpha=opacity, color='b', label='0')
    p2 = plt.bar(index, class_1, bar_width, bottom=class_0, alpha=opacity, color='g', label='1')

    plt.xlabel('Stations')
    plt.ylabel('Samples')
    plt.title('Samples per Station')

    station_labels = list(range(1, len(results) + 1))
    station_labels = [str(x) for x in station_labels]
    station_labels.append('All')

    plt.xticks(index, station_labels)
    plt.legend((p1[0], p2[0]), ('0', '1'))
    plt.legend()

    plt.tight_layout()
    plt.savefig('discovery.png')
    plt.show()



class Train:
    def __init__(self, data_path=None, results=None):
        # Model and results encoded with Pickle
        self.data_path = data_path
        self.results = results

    def _load_results(self):
        try:
            with open(self.results, 'rb') as results_file:
                return pickle.load(file=results_file)
        except:
            return {'analysis': {}, 'discovery': {}}

    def _save_results(self, results):
        with open(self.results, 'wb') as results_file:
            return pickle.dump(results, results_file)

    def discovery(self):
        results = self._load_results()

        # Data Loading and class encoding
        x, y = _load_sequences_as_encoded(self.data_path, class_labels={
            _CCR5: 1,
            _CXCR4: 0
        })

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.10)
        classes = np.array([0, 1])
        total_samples = len(x_train) + len(x_test)

        class_1 = np.count_nonzero(y_train) + np.count_nonzero(y_test)
        class_0 = total_samples - class_1
        discovery = {'total_samples': total_samples,
                     'classes': classes.tolist(),
                     'class_0_num': class_0,
                     'class_1_num': class_1}
        results['discovery']['discovery_exec_' + str(len(results['discovery']) + 1)] = discovery

        plot_results(results['discovery'])
        print(results)
        self._save_results(results=results)


def main():
    plot_results({'discovery_exec_1': {'total_samples': 168, 'classes': [0, 1], 'class_0_num': 23, 'class_1_num': 145},
                   'discovery_exec_2': {'total_samples': 128, 'classes': [0, 1], 'class_0_num': 21, 'class_1_num': 107},
                   'discovery_exec_3': {'total_samples': 141, 'classes': [0, 1], 'class_0_num': 8, 'class_1_num': 133},
                   'discovery_exec_4': {'total_samples': 131, 'classes': [0, 1], 'class_0_num': 37, 'class_1_num': 94},
                   'discovery_exec_5': {'total_samples': 198, 'classes': [0, 1], 'class_0_num': 35,
                                        'class_1_num': 163}})
    #train = Train(data_path='/data/sequence.txt', results='results.pkl')
    #train.discovery()


if __name__ == '__main__':
    main()

